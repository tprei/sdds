repo: tprei/sdds
branch: sdds/remove-place-domain

## Last sync
date: 2026-07-31T12:32:41Z
commit: a66554b04613e6d0ebc581a8481d5d9ce5fa775a

### Updated in this project
- Read `packages/tokens/src/index.ts` (colors, semanticColors, categoryColors, spacing, radius, typography, shadows, motion, componentMetrics, fontFamilies, avatar palette)
- Read all `apps/mobile/src/ui/` primitives (text, button, chips, tab-bar, avatar, metric-stat, fields, sheet, skeleton, masonry, icons, etc.)
- Read feature components: note-card, post-it-composer, home-header, search-idle, note-action-bar, brand-header, category-filter-controls
- Built "Sistema de Design sdds.dc.html" — canonical design-system reference + principles + agent rules

## Screen map
| Project screen/section | Repo files |
| --- | --- |
| Tokens (cor/tipo/espaço/sombra/motion) | packages/tokens/src/index.ts |
| Componentes (galeria) | apps/mobile/src/ui/*.tsx, apps/mobile/src/ui/*.styles.ts, apps/mobile/src/components/note-card.* |
| Telas: Início | apps/mobile/src/app/(tabs)/index.tsx, features/notes/home-header.tsx, ui/masonry-grid.*, ui/grid-layout.ts |
| Telas: Buscar | apps/mobile/src/app/(tabs)/search.tsx, features/notes/search-idle.*, ui/search-field.* |
| Telas: Escrever | apps/mobile/src/app/compose.tsx, features/notes/post-it-composer.* |
| Telas: Nota | apps/mobile/src/app/notes/[id].tsx, features/notes/note-action-bar.* |
| Telas: Salvos/Perfil/Login | apps/mobile/src/app/(tabs)/saved.tsx, (tabs)/profile.tsx, app/login.tsx, features/auth/brand-header.* |
